
import React from 'react';

function App() {
  return (
    <div style={{ color: 'lime', backgroundColor: 'black', height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <h1>J6 Online</h1>
    </div>
  );
}

export default App;
